package com.jgr.micro.cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbServicioCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
