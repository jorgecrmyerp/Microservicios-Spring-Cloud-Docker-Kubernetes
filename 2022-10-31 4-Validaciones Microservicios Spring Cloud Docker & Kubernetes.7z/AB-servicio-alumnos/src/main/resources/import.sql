INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO1', 'PASSWORD1', 'email1@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO2', 'PASSWORD2', 'email2@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO3', 'PASSWORD3', 'email3@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO4', 'PASSWORD4', 'email4@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO5', 'PASSWORD5', 'email5@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO6', 'PASSWORD6', 'email6@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO7', 'PASSWORD7', 'email7@asdf.com',NOW());
INSERT INTO alumnos(nombre, password, email,create_at) VALUES('ALUMNO8', 'PASSWORD8', 'email8@asdf.com',NOW());