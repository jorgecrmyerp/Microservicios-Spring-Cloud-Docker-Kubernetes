package com.jgr.micro.alumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
