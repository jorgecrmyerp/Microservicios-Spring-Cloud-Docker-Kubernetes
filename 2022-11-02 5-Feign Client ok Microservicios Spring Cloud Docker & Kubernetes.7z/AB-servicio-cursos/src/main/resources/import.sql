INSERT INTO cursos(nombre,create_At) VALUES('Curso1',NOW());
INSERT INTO cursos(nombre,create_At) VALUES('Curso2',NOW());
INSERT INTO cursos(nombre,create_At) VALUES('Curso3',NOW());
INSERT INTO cursos(nombre,create_At) VALUES('Curso4',NOW());
INSERT INTO cursos(nombre,create_At) VALUES('Curso5',NOW());
INSERT INTO cursos_alumnos(alumno_id,curso_id) VALUES(1,1); 